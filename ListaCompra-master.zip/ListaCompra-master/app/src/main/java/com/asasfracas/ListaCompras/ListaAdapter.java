package com.asasfracas.ListaCompras;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

public class ListaAdapter extends RecyclerView.Adapter{
 private List<ListaCompra> produto;


    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent,int ViewType){
        return null;
    }
    public void onBindViewHolder(RecyclerView.ViewHolder holder,int position){

    }

    public int getItemCount(){
        return 0;
    }

    private class ViewholderLista extends RecyclerView.ViewHolder(){
        public ViewholderLista(View itemView){
            super(itemView);
        }
    }
}
